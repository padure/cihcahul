-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 03 Noi 2017 la 12:47
-- Versiune server: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cihcahul`
--

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `acte`
--

CREATE TABLE `acte` (
  `id` int(11) NOT NULL,
  `titlu` varchar(255) NOT NULL,
  `descriere` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='id, titlu, descriere, icon';

--
-- Salvarea datelor din tabel `acte`
--

INSERT INTO `acte` (`id`, `titlu`, `descriere`, `icon`) VALUES
(1, 'Buletin de identitate', '3 copii (xerox)', 'icon-rocket'),
(2, 'Certificat de naștere', '1 copie (xerox)', 'icon-bubbles'),
(3, 'Certificat medical', 'Forma 086-E, eliberat în anul admiterii', 'icon-handbag'),
(4, 'Fotografii pentru acte', '6 fotografii 3×4 color', 'icon-plus-sign-alt'),
(5, 'Buletinului de identitate al unui părinte', '1 copie (xerox)', 'icon-settings'),
(6, 'Adeverinţa de premilitar sau a livretului militar', '1 copie(xerox)-pentru băieți', 'icon-handbag'),
(7, 'Actul de studii în original', 'Certificat de studii gimnaziale, diploma de bacalaureat, atestat de studii medii de cultură generală', 'icon-layers'),
(8, 'Adeverință de confirmare', 'Pentru copiii orfani şi copiii rămaşi fără îngrijirea părinţilor, eliberată de organul de tutelă şi curatelă din localitate ori de hotărîrea de judecată.', 'icon-handbag'),
(10, 'Certificatul despre componenţa familiei', 'Pentru candidații din familiile cu 4 și mai mulți copii', 'icon-handbag');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `administratias`
--

CREATE TABLE `administratias` (
  `id` int(11) NOT NULL,
  `nume` varchar(200) NOT NULL,
  `functie` varchar(100) NOT NULL,
  `descriere` varchar(400) NOT NULL,
  `image` varchar(400) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Salvarea datelor din tabel `administratias`
--

INSERT INTO `administratias` (`id`, `nume`, `functie`, `descriere`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Tataru Gheorghe', 'Director', 'Grad managerial unu,profesor de chimie , grad didactic unu', 'assets\\img\\team\\DSC_8573.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'Chihai Raisa', 'Director adjunct', 'Grad didactic superior,profesor discipline de specialitate', 'assets\\img\\team\\DSC_8613.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'Tataru Svetlana', 'Șef Practică', 'Grad didactic superior,profesor de biologie', 'assets\\img\\team\\DSC_8545.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'Bostănel Sabrina', 'Șef catedră Filologie', 'Grad didactic superior,profesor de istorie', 'assets\\img\\team\\DSC_8617.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'Ianocoglo Margareta', 'Șef secție Pedagogie și Asistență Socială', 'Grad didactic unu,profesor discipline de specialitate', 'assets\\img\\team\\DSC_8536.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'Lupu Nelea', 'Șef Secție Contabilitate', 'Grad didactic unu,profesor de istorie', 'assets\\img\\team\\DSC_8555.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'Gliboceanu Ludmila', 'Șef Secție Arte', 'Grad didactic superior,profesor discipline de specialitate', 'assets\\img\\team\\DSC_8567.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'Rența Valentina', 'Metodist', 'Grad didactic superior,profesor de istorie', 'assets\\img\\team\\DSC_8551.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'Bobeico Maria', 'Șef Secție Informatică', 'Grad didactic unu,profesor de matematică', 'assets\\img\\team\\DSC_8514.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'Costandachi Rita', 'Șef Catedră Științe Reale', 'Grad didactic unu,profesor de matematică', 'assets\\img\\team\\DSC_8583.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'Jolea Ecaterina', 'Șef Catedră Contabilitate', 'Grad didactic doi,profesor discipline de specialitate', 'assets\\img\\team\\DSC_8578.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'Chihai Ion', 'Șef Catedră Arte', 'Grad didactic doi,profesor discipline de specialitate', 'assets\\img\\team\\DSC_8530.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 'Pârvan Evgheni', 'Șef Catedră Informatică', 'Grad didactic superior,profesor discipline de specialitate', 'assets\\img\\team\\DSC_8521.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 'Loghin Natalia', 'Contabil Șef', 'Grad didactic unu,profesor discipline de specialitate', 'assets\\img\\team\\DSC_8560.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 'Zbîrciog Tatiana', 'Economist', 'Grad didactic unu,profesor discipline de specialitate', 'assets\\img\\team\\DSC_8522.jpg', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `content` longtext NOT NULL,
  `author` varchar(50) DEFAULT NULL,
  `description` varchar(400) NOT NULL,
  `date` date NOT NULL,
  `image` varchar(400) NOT NULL,
  `views` int(11) NOT NULL,
  `tags` varchar(300) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Salvarea datelor din tabel `articles`
--

INSERT INTO `articles` (`id`, `title`, `content`, `author`, `description`, `date`, `image`, `views`, `tags`, `created_at`, `updated_at`) VALUES
(1, 'PRACTICA DE INITIERE ÎN SPECIALITATE LA INFORMATICĂ', '<p>Conform planului de învăţământ, practica instructivă a elevilor de la specialitatea „Informatică” se realizează la sfârşitul semestrului II în laboratoarele de informatică ale colegiului în decurs de 2 săptămâni (60 de ore academice). Laboratoarele sunt bine dotate atât cu echipamente tehnice de calcul cât şi cu produse soft.</p>\r\n<p>Obiectivele generale ale practicii instructive:</p>\r\n<ul>\r\n<li>Consolidarea cunoştinţelor teoretice, obţinute de elevi pe parcursul studierii limbajelor de programare (Turbo Pascal, Procesarea textului, calcul tabelar, prezentări multimedia, Comunicație electronică );</li>\r\n<li>Însuşirea tehnologiei de elaborare a programelor;</li>\r\n<li>Dezvoltarea abilităţilor muncii de sine stătător și în echipă;</li>\r\n<li>Formarea deprinderilor de cercetător.</li>\r\n</ul>\r\n<p>Elevul la practica de instruire imită întregul proces de elaborare a unui set de programe, ce-i permite să evolueze în rolul de elaborator şi organizator al proiectului.</p>\r\n<p>Sarcina individuală pentru elev constă dintr-un set de probleme, formulate în aşa mod, încât să cuprindă cât mai deplin toate compartimentele cursului studiat. În procesul lucrului de sine stătător asupra sarcinii individuale, elevii elaborează şi descriu algoritmi într-un limbaj de programare, testează şi depanează programele respective.</p>\r\n<p>La finele practicii, elevii au prezintat proiectele realizate sub formă de raport, care este salvat în portofoliul electronic de pe google drive, și care este evaluat şi notat de conducătorul practicii.</p>', 'Blaja Maria', 'Conform planului de învăţământ, practica instructivă a elevilor de la specialitatea „Informatică” se realizează la sfârşitul semestrului II în laboratoarele de informatică ale colegiului în decurs de 2 săptămâni (60 de ore academice). Laboratoarele sunt bine dotate atât cu echipamente tehnice de calcul cât şi cu produse soft.', '2017-10-25', 'assets\\img\\events\\practica.jpg', 56, 'Practica', '2017-10-25 12:33:17', '2017-10-25 10:33:17'),
(2, 'DECADA CATEDREI DE ECONOMIE', '<p>Catedra de Economie funcţionează în cadrul Colegiului Industrial Pedagogic din Cahul, asigurînd suportul şi pregatirea economică la toate disciplinele din cadrul Catedrei</p>\r\n<p>Misiunea catedrei este atragerea elevilor buni în scopul de a-i face profesionişti pe piaţa forţei de munca!Pregătirea elevilor şi absolvenţilor de profil economic la standarde europene şi internaţionale pentru executarea, coordonarea şi conducerea proceselor de producţie (activităţilor economice) în următoarele direcţii: restructurări în economia Republicii Moldova în actualul context al realizării integrării efective în piaţa unică europeană, flexibilizarea activităţii economice, marketingul şi promovarea permanentă a strategiilor de piaţă, modelarea procesului promoţional cu dimensiunile contemporane ale evoluţiei marketingului.</p>\r\n<p>În perioada 30 martie – 3 aprilie 2015 Catedra de Economie a Colegiului a desfăşurat mai multe activităţi avînd ca scop fundamental formarea cadrelor economice cu calificare preuniversitară ânaltă acoperind o arie largă de sarcini de la cele tehnice la cele economice, de inovare sau de producţie orientată către piaţă.</p>\r\n<p>În cadrul acestor activităţi au avut loc concursuri, inaugurări şi prezentări ale Firmelor de Exerciţiu: „Eternal Beauty” SRL, Ziua tranzacţiilor în cadrul Firmelor de exerciţiu, 31 martie, 2015, grupa C1232; Inaugurarea F.E. „Dian Rom” SRL, 1 aprilie, 2015, Grupa C1231; Lansarea produselor noi de Paşti, F. E. „CREATIV” SRL, 2 aprilie, 2015, grupa C1232; Brain Ring-ul din 3 aprilie, 2015, concursul pentru cel mai bun elev la specialitatea Contabilitate.</p>\r\n<p> Încununarea acestor activităţi a avut loc vineri, 24 aprilie la Târgul Firmelor de Exerciţiu, activitate desfăşurată în incinta Colegiului Financiar Bancar, or. Chişinău; târg la care elevii şi profesorii Catedrei de Economie a Colegiului Industrial Pedagogic din Cahul au dat dovadă de profesionalism şi o temeinică pregătire teoretică şi practică, fiind apreciaşi cu diplome şi menţiuni de participare: „CREATIV” SRL, Locul I, profesor – coordonator, JOLEA ECATERINA; diplome de participare au obţinut Firmele de Exerciţiu „Eternal Beauty” SRL, profesor –coordonator Tagârş Roman, „Mega Comp SRL, profesor –coordonator Gârneţ Ionela, „Dian Rom” SRL, profesor- coordonator, Jolea Ecaterina </p>', 'Blaja Maria', 'Catedra de Economie funcţionează în cadrul Colegiului Iulia Hasdeu din Cahul, asigurînd suportul şi pregatirea economică la toate disciplinele din cadrul Catedrei.Misiunea catedrei este atragerea elevilor buni în scopul de a-i face profesionişti pe piaţa forţei de munca!', '2017-10-25', 'assets\\img\\events\\decada.jpg', 110, 'Decada', '2017-10-25 12:32:30', '2017-10-25 10:32:30'),
(3, 'FESTIVALUL - CONCURS “CAHUL  STAR” EDIŢIA A VII', '<p>La concurs au participat elevi ai anului I - IV, selectaţi printr-un concurs intern sau laureaţi ai altor concursuri care au demonstrat aptitudini vocale, creativitate în selectarea repertoriului, artistism. Repertoriul a cuprins: o piesă pe versurile poetului Grigore Vieru; o piesă  din repertoriul muzicii de estradă sau a muzicii populare la alegerea liberă a concursantului.</p>\r\n<p>Juriul a apreciat evoluarea în scenă a tinerilor, conform următoarelor criterii: ţinuta scenică; calitatea interpretării; originalitatea repertoriului; măiestria interpretativă; expresivitatea; artistismul;creativitatea. Premiul cel mare al concursului i-a revenit elevului grupei A – 3, Sergiu Bunescu; Premiul I – Veronica Lozovenu, grupa A-4 şi Demcicova Svetlana, grupa I-1242; Premiul II – Mihai Tatiana, grupa C- 1412; Premiul III – Bunea Viorica, grupa K-1411.</p>\r\n', 'Admin', 'La concurs au participat elevi ai anului I - IV, selectaţi printr-un concurs intern sau laureaţi ai altor concursuri care au demonstrat aptitudini vocale, creativitate în selectarea repertoriului, artistism.', '2015-04-07', 'assets\\img\\events\\festival.jpg', 100, 'Festival', '2017-10-16 21:42:00', '2017-10-16 19:42:00'),
(4, 'ZIUA DRAPELULUI NAȚIONAL AL REPUBLICII MOLDOVA', '<p> La 27 aprilie 2015, la Colegiul Industrial – Pedagogic din Cahul a fost consemnată Ziua Drapelului de Stat al Republicii Moldova.  Elevii Colegiului Industrial- Pedagogic, împreună cu profesorii, au omagiat însemnul cel mai sfânt al identităţii noastre naţionale – TRICOLORUL. </p>\r\n<p>Această zi a fost instituită de Parlamentul de la Chișinăula 23 aprilie 2010. Tricolorul a fost desemnat oficial drapel de stat pe 27 aprilie 1990 de către deputații primului Legislativ.</p>\r\n<p>Au fost interpretate cantece patriotice, elevii secţiei Coregrafie au organizat un flash - mob invocând frumuseţea şi măreţia drapelului naţional.</p>', 'Admin', 'La 27 aprilie 2015, la Colegiul Industrial – Pedagogic din Cahul a fost consemnată Ziua Drapelului de Stat al Republicii Moldova.  Elevii Colegiului Industrial- Pedagogic, împreună cu profesorii, au omagiat însemnul cel mai sfânt al identităţii noastre naţionale – TRICOLORUL.', '2014-04-23', 'assets\\img\\events\\tricolor.jpg', 142, 'Tricolor', '2017-10-16 22:45:56', '2017-10-16 20:45:56'),
(5, 'DECADA CATEDREI DE PEDAGOGIE, PSIHOLOGIE ŞI ASISTENŢĂ SOCIALĂ ', '<p>În perioada 20 noiembrie - 2 decembrie 2014, la Colegiul Industrial - Pedagogic din or. Cahul a avut loc Decada Catedrei de Pedagogie, Psihologie şi Asistenţă Socială.</p>\r\n<p>În cadrul Decadei au fost desfăşurate activităţi de voluntariat cu prilejul sărbătorii Hramului oraşului Cahul, „Arhanghelul Mihail şi Gavriil” (21.11.2014, responsabili Anastasia Scripcenco, Margareta Ianacoglo şi Larisa Dănilî, grupa AS-1231);Pe data de 2.12.2014 a fost organizat un training pentru diriginţi pe tema „Rolul empatiei în competenţa didactică” (responsabil Alexandra Piscunov, Larisa Dănilî)</p>\r\n<p>Activităţi de voluntariat  în centrele de plasament: „MANFREDI”, „Centrul Protecţiei Familiei şi Copilului în Dificultate”, responsabili Alexandra Piscunov, Larisa Dănilî, Margareta Ianacoglo, Marina Zorilă, Margareta Gârneţ; Iarmarocul de caritate: „Un dar mic, o faptă bună” (24.11.2014, responsabil Oxana Bob, Larisa Dănilî , Margareta Ianacoglo ,grupele AS-1231, AS -1232);</p>\r\n<p>De asemenea, au avut loc ore publice de dirigenţie: „O oră de frumuseţe – o oră de suflet”, responsabil Alecsandra Piscunov ,Gr. PPr – 1141; „Consecinţele avortului”, „Suicidul şi prevenirea lui în societate”,  (28.11.2014, reesponsabil Valentina Chiosa, Grupa AS- 1142);</p>\r\n<p>Concursul de eseuri cu genericul: „Ziua Internaţională a Eliminării Violenţei Împotriva Femeii” (25.11. 2014, responsabili Margareta Ianacoglo, Larisa Dănilî, Valentina Chiosa, Marina Zorilă);</p>\r\n<p>Concursul sportiv „Starturi Vesele” (26. 11.14, responsabil Leonid Brezan, Andrei Ştefăniţă, au participat în concurs grupele  PPr. – 1231, AS- 1321, As-1321).</p>\r\n', 'Admin', 'Pe data de 5 martie 2015, în Sala de Festivităţi a Colegiului Industrial – Pedagogic din Cahul a avut loc activitatea extracurriculară „Sărut, Femeie, mâna ta” organizată de profesorul de matematică, Catedra Ştiinţe Reale, Oleacov Liliana.', '2015-03-05', 'assets\\img\\events\\1.jpg', 132, 'Decada', '2017-10-16 11:58:24', '2017-10-16 09:58:24'),
(6, 'Ultimul Sunet', '<pre><center>Ultimul sunet… Ultimul careu…\r\nAzi absolvenţi sântem şi noi…\r\nE vesel, dar totodată e atât de greu,\r\nCăci deacum ne despărţim de voi…\r\n\r\nÎmpreună acelaşi drum noi am parcurs,\r\nUn drum prin care multe am învăţat.\r\nŞi acum privim în urmă – patru ani s-au scurs…\r\nCind?... Că nici nu i-am observat…\r\n\r\nAu fost ani frumoşi de paradis,\r\nCare nu se vor repeta niciodată.\r\nDar dacă nouă ne-ar fi permis,\r\nI-am trăi din nou şi nu numai o dată.\r\n\r\nAm avut şi lacrimi, am avut şi bucurii…\r\nUn univers enigmatic am descoperit.\r\nŞi printre lecţii, practici şi stagii\r\nO viaţă de colegiu am trăit\r\n\r\nAm avut şi soare, am avut şi nori,\r\nDar peste toate am trecut.\r\nAlături de voi, scumpi profesori,\r\nPlanuri mari noi am făcut.\r\n\r\nAstăzi cu toţii vă mulţumim\r\nŞi pînă la pământ ne închinăm,\r\nCăci ne-aţi învăţat oameni să fim\r\nŞi-n toate să ne descurcăm.\r\n\r\nVor mai trece ani de-a rîndul\r\nŞi noi departe ne vom afla,\r\nDar să stiţi că noi cu gândul\r\nAici, lângă voi ne vom afla.\r\n\r\nAzi încă o amintire se adună\r\nÎn buchetul ce-l vom răscoli mereu –\r\nE clopoţelul care sună...\r\nE ultimul sunet... e ultimul careu...</center></pre>', 'admin', 'Ultimul sunet…/Ultimul careu…/\r\nAzi absolvenţi sântem şi noi…/\r\nE vesel, dar totodată e atât de greu,/\r\nCăci deacum ne despărţim de voi…/\r\n\r\nÎmpreună acelaşi drum noi am parcurs,/\r\nUn drum prin care multe am învăţat./\r\nŞi acum privim în urmă – patru ani s-au scurs…/\r\nCind?... Că nici nu i-am observat…/\r\n', '2017-05-31', 'assets\\img\\events\\ultimsunet.jpg', 357, '', '2017-10-16 17:50:30', '2017-10-16 15:50:30'),
(7, 'Prezentarea lucrărilor de diplomă în cadrul secției Informatica', '<p>Astăzi, 20.06.2017 are loc prezentarea lucrării de diplomă la specialitatea „Informatică”</p>\r\n<p>Sarcina individuală pentru elev constă din proiectarea unui sistem informatic, formulate în aşa mod, încât să cuprindă cât mai deplin toate compartimentele cursului studiat. În procesul lucrului de sine stătător asupra sarcinii individuale, elevii elaborează şi descriu algoritmi într-un limbaj de programare, testează şi depanează programele respective.</p>\r\n', 'admin', 'Astăzi, 20.06.2017 are loc prezentarea lucrării de diplomă la specialitatea „Informatică”', '2017-06-20', 'assets\\img\\events\\20170620_092537.jpg', 486, '', '2017-10-25 09:41:15', '2017-10-25 07:41:15'),
(9, '1 SEPTEMBRIE – Ziua cunoștințelor', '<p>1 SEPTEMBRIE &ndash; Ziua cunoștințelor&nbsp;<br />\nAstăzi 1 septembrie 2017, a fost o zi plină de emoții, vise, z&acirc;mbete și flori, o mare sărbatoare pentru Colegiul ,,Iulia&nbsp;Hasdeu&rdquo;din or. Cahul, dar și pentru toate instutuțiile de &icirc;nvățăm&acirc;nt din țara noastră, care au sărbatorit prima zi de școală- Ziua Cunoștințelor.&nbsp;<br />\nPărinţii, profesorii dar și reprezentanţi ai Consiliului Raional Cahul au venit să sărbătorească &icirc;nceputul noului an de studii. Aceștia au transmis urări de bine și felicitari at&acirc;t elevilor din anul II, III și IV c&acirc;t și boboceilor din anul I, care a pășit entuziasmați pragul colegiului.&nbsp;<br />\nAu fost oferite diplome tuturor elevilor care s-au remaract prin rezultate deosebite la &icirc;nvățătură &icirc;n anul de studii 2016-2017, deasemenea au primit diplome și elevii ce s-au implicat activ &icirc;n activitățile organizate pe tot parcursul anului de &icirc;nvățăm&acirc;nt.</p>\n', 'Blaja Maria', 'Astăzi 1 septembrie 2017, a fost o zi plină de emoții, vise, zâmbete și flori, o mare sărbatoare pentru Colegiul ,,Iulia Hasdeu”din or. Cahul , dar și pentru toate instutuțiile de învățământ din țara noastră, care au sărbatorit prima zi de școală- Ziua Cunoștințelor...', '2017-09-01', 'assets\\img\\events\\septembrie.jpg', 173, 'Septembrie', '2017-10-31 15:28:42', '2017-10-31 14:28:42'),
(10, 'Colegiul „Iulia Hasdeu” anunță organizarea concursului pentru ocuparea funcției de director adjunct instruire și educație.', '<p><span style=\"font-size:12px\"><span style=\"color:#000000\"><em>Extras din Ordinul</em></span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\"><em>Nr. <u>60/B </u>din <u>29.09.2017</u></em></span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\"><strong>Colegiul &bdquo;Iulia Hasdeu&rdquo; din or. Cahul (3900, Cahul, str. Dunării, nr. 36) anunță concurs pentru ocuparea funcției vacante de director adjunct instruire și educație.</strong></span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\"><u>Cerințele postului:</u></span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">1. Cetățean al Republicii Moldova;</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">2. Studii superioare universitare;</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">3. Are vechime de muncă &icirc;n activitatea didactică de cel puțin 5 ani și deține grad didactic;</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">4. La data expirării termenului de depunere a dosarelor nu a &icirc;mplinit v&icirc;rsta de 65 ani;</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">5. Cunoaște limba rom&acirc;nă;</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">6. Reputație ireproșabilă;</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">7. Lipsa antecedentelor penale, sancțiunilor disciplinare și administrative.</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">La &icirc;nscrierea pentru concurs, candidații vor depune un dosar, care include următoarele acte:</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">1.Cerere pentru participare la concurs cu menționarea postului solicitat;</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">2. Copia actului de identitate;</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">3. Copia/copiile actului/actelor de studii;</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">4. Copia carnetului de muncă;</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">5. Curriculum Vitae de model Europass;</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">6. Certificatul medical care atestă faptul că persoana este aptă din punct de vedere medical, fizic (eliberat de medicul de familie) şi neuropsihic (eliberate de psihiatru/narcolog) pentru exercitarea funcției;</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">7. Cazier judiciar sau declarația pe propria răspundere.</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">Candidatul poate anexa și alte documente pe care le consideră relevante, inclusiv copiile actelor ce confirmă gradul didactic/managerial și/sau titlul științific/științifico-didactic, recomandări, lista publicațiilor didactice și științifice etc.</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">Doar candidații care &icirc;ntrunesc toate condițiile de participare la concurs (cerințele postului) vor fi invitați pentru interviu.</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">Dosarele vor fi depuse la Colegiul &bdquo;Iulia Hasdeu&rdquo; din or. Cahul, biroul 119, p&icirc;nă la data de 26.10.2017 inclusiv, &icirc;ntre orele 08<sup>00</sup>- 17<sup>00</sup>, cu excepția zilelor de s&icirc;mbătă și duminică.</span></span></p>\r\n\r\n<p><span style=\"font-size:12px\"><span style=\"color:#000000\">Persoana responsabilă de recepționarea dosarelor și furnizarea informațiilor suplimentare referitor la organizarea concursului &ndash; dna Jolea Ecaterina, specialist serviciu personal. tel: 29941650; e-mail: </span><a href=\"mailto:j.e.m@rambler.ru\"><span style=\"color:#000000\">j.e.m@rambler.ru</span></a><span style=\"color:#000000\">; cihsecretariat@cihcahul.md</span></span></p>\r\n', 'Administraţia', 'Colegiul „Iulia Hasdeu” din or. Cahul (3900, Cahul, str. Dunării, nr. 36) anunță concurs pentru ocuparea funcției vacante de director adjunct instruire și educație.', '2017-10-06', 'assets\\img\\events\\director.jpg', 86, 'anunt', '2017-10-16 21:15:07', '2017-10-16 19:15:07'),
(11, 'Decada Catedrei de Economie', '<p style=\"font-size:16px; text-align: justify;\"><strong>Tradițional în luna octombrie, </strong><strong>în</strong><strong> Colegiului ,,Iulia Hasdeu” din Cahul se desfășoară decada Catedrei de Economie. Cu această ocazie, elevii specialității Contabilitate sunt implicați activ în numeroase evenimente cu tematică de specialitate.</strong></p>\r\n\r\n<p><img class=\"img-responsive\" src=\"http://cihcahul.md/assets\\img\\events\\ec1.jpg\" /></p>\r\n\r\n<p style=\"font-size:16px; text-align: justify;\">Catedra de Economie asigură suportul şi pregătirea economică la toate disciplinele de profil. Obiectivul principal al catedrei este ghidarea elevilor în scopul de a-i face profesionişti și competitivi pe piaţa forţei de muncă, de asemenea pregătirea elevilor şi absolvenţilor de profil economic la standarde europene şi internaţionale pentru executarea, coordonarea şi conducerea proceselor de producţie .</p>\r\n\r\n<p style=\"font-size:16px; text-align: justify;\">Săptămâna dedicată Catedrei de Economie s-a început cu un concurs al gazetelor de perete cu tematica “Cea mai bună idee de afacere”, în care elevii specialității contabilitate și-au demonstrat spiritul creativ și inovativ.</p>\r\n\r\n<p><img class=\"img-responsive\" src=\"http://cihcahul.md/assets\\img\\events\\ec2.jpg\" /></p>\r\n\r\n<p style=\"font-size:16px; text-align: justify;\">Tot în cadrul acestei săptămâni a avut loc inaugurarea și prezentarea Firmelor de Exerciţiu:<b> „Eternal Beauty” SRL, „Dian Rom” SRL, „CREATIV” SRL</b>, eveniment organizat și prezentat de elevii anului IV. Firma de exercițu servește drept o metodă interactivă de învățare pentru dezvoltarea spiritului antreprenorial, o concepție modernă de integrare și de aplicare a cunoștințelor, o abordare care asigură condiții pentru aprobarea și aprofundarea practică a competențelor dobândite de elevi în pregătirea profesională.</p>\r\n\r\n<p><img class=\"img-responsive\" src=\"http://cihcahul.md/assets\\img\\events\\ec3.jpg\" /></p>\r\n\r\n<p style=\"font-size:16px; text-align: justify;\">Decada s-a încheiat cu un Brain Ring sub genericul “Contabilitatea decontarilor cu personalul privind retribuirea muncii’’.</p>\r\n\r\n<p><img class=\"img-responsive\" src=\"http://cihcahul.md/assets\\img\\events\\ec4.jpg\" /></p>', 'Blaja Maria', 'Tradițional în luna octombrie, în Colegiului ,,Iulia Hasdeu” din Cahul se desfășoară decada Catedrei de Economie. Cu această ocazie, elevii specialității Contabilitate sunt implicați activ în numeroase evenimente cu tematică de specialitate.', '2017-10-31', 'assets\\img\\events\\dececonomie.jpg', 20, 'Decada', '2017-11-03 11:46:03', '2017-11-03 10:46:03'),
(19, 'Rezultat etapa I al concursului pentru ocuparea funcției de director adjunct instruire și educație.', '<p><span style=\"font-size:14px\"><span style=\"color:#000000\"><em>Ca urmare a examinării dosarelor de concurs pentru ocuparea  funcției vacante de director adjunct instruire și educație, Comisia de concurs a decis de a admite la următoarea etapă, ce se va desășura pe data de 7 noiembrie 2017, următorul candidat: Zbîrciog Tatiana.</em></span></span></p>', 'Administraţia', 'Colegiul „Iulia Hasdeu” din or. Cahul (3900, Cahul, str. Dunării, nr. 36) anunță concurs pentru ocuparea funcției vacante de director adjunct instruire și educație.', '2017-11-03', 'assets\\img\\events\\director.jpg', 15, 'anunt', '2017-11-03 11:46:29', '2017-11-03 10:46:29');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `carousels`
--

CREATE TABLE `carousels` (
  `id` int(11) NOT NULL,
  `image` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `carousels`
--

INSERT INTO `carousels` (`id`, `image`) VALUES
(1, 'assets\\img\\index_slider\\1.jpg'),
(2, 'assets\\img\\index_slider\\2.jpg'),
(3, 'assets\\img\\index_slider\\3.jpg'),
(4, 'assets\\img\\index_slider\\4.jpg\r\n'),
(5, 'assets\\img\\index_slider\\5.JPG'),
(6, 'assets\\img\\index_slider\\6.JPG');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `catedres`
--

CREATE TABLE `catedres` (
  `id` int(11) NOT NULL,
  `nume` varchar(100) NOT NULL,
  `content` longtext CHARACTER SET utf8 NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `catedres`
--

INSERT INTO `catedres` (`id`, `nume`, `content`, `created_at`, `updated_at`) VALUES
(1, 'Catedra de Informatica', '<div class=\"col-md-6 catedra-title\">\r\n                        <div class=\"col-md-12 bg-blue\">\r\n                            \r\n                            <p>Catedra de</p>Informatică<br>\r\n                            <i class=\"material-icons\" style=\"font-size:90px;\">computer</i>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"col-md-6 catedra-content\">\r\n                        <div class=\"col-md-6 padding\">\r\n                            <img src=\"assets/img/team/DSC_8521.jpg\" alt=\"\" class=\"img-responsive\">\r\n                        </div>\r\n                        <div class=\"col-md-6 padding\">\r\n                            <span>Pârvan Eugen</span>\r\n                            <small>- Șef Catedră Informatică -</small>\r\n                            <p>Grad didactic superior, profesor discipline de specialitate</p>\r\n<p><b>Email:</b> eparvan@gmail.com</p>\r\n                        </div>\r\n                        <div class=\"col-md-12 col-sm-12 description-catedra\">\r\n                            <p>Disciplinele din cadrul catedrei:</p>\r\n                            <ul>\r\n                                <li>Proiectarea şi Crearea Paginilor WEB (HTML, CSS, PHP, JavaScript);</li>\r\n                                <li>Reţele de Calculatoare;</li>\r\n                                <li>Programarea Orientată spre Obiecte( C# );</li>\r\n                                <li> Sisteme de Gestiune a Bazelor de Date [...]</li>   \r\n                            </ul>\r\n                            <p><a class=\"btn-u btn-u-sm\" href=\"\">Read More <i class=\"fa fa-angle-double-right margin-left-5\"></i></a></p>\r\n                        </div>\r\n                    </div>', '2017-11-03 11:24:48', '2017-11-03 10:24:48'),
(2, 'Catedra de Stiinte Reale', '<div class=\"col-md-6 catedra-content\">\r\n                        <div class=\"col-md-6 padding\">\r\n                            <img src=\"assets/img/team/user-d.png\" alt=\"\" class=\"img-responsive\">\r\n                        </div>\r\n                        <div class=\"col-md-6 padding\">\r\n                            <span>Ganev Marina</span>\r\n                            <small>- Șef Catedră Științe Reale -</small>\r\n                            <p>Grad didactic doi, profesor de matematică</p>\r\n<p><b>Email:</b> ganevmarina34@gmail.com</p>\r\n                        </div>\r\n                        <div class=\"col-md-12 col-sm-12 description-catedra\">\r\n                            <p>Disciplinele din cadrul catedrei:</p>\r\n                            <!--ul>\r\n                                <li>Proiectarea şi Crearea Paginilor WEB(HTML, CSS, PHP, JavaScript);</li>\r\n                                <li>Reţele de Calculatoare;</li>\r\n                                <li>Programarea Orientată spre Obiecte(JAVA);</li>\r\n                                <li> Sisteme de Gestiune a Bazelor de Date [...]</li>   \r\n                            </ul-->\r\n                            <p><a class=\"btn-u btn-u-sm\" href=\"\">Read More <i class=\"fa fa-angle-double-right margin-left-5\"></i></a></p>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"col-md-6 catedra-title\">\r\n                        <div class=\"col-md-12 bg-blue\">\r\n                            \r\n                            <p>Catedra de </p>Ştiinţe Reale<br>\r\n                            <i class=\"fa fa-balance-scale\" style=\"font-size:90px\"></i>\r\n                        </div>\r\n                    </div>', '2017-11-03 10:49:59', '2017-11-03 09:49:59'),
(3, 'Catedra de Arte', '<div class=\"col-md-6 catedra-title\">\r\n                        <div class=\"col-md-12 bg-blue\">\r\n                            \r\n                            <p>Catedra de </p>Arte<br>\r\n                            <i class=\"fa fa-music\" style=\"font-size:90px\"></i>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"col-md-6 catedra-content\">\r\n                        <div class=\"col-md-6 padding\">\r\n                            <img src=\"assets/img/team/user-d.png\" alt=\"\" class=\"img-responsive\">\r\n                        </div>\r\n                        <div class=\"col-md-6 padding\">\r\n                            <span>Lilia Camenschi</span>\r\n                            <small>- Șef Catedră Arte -</small>\r\n                            <p>Grad didactic doi, profesor discipline de specialitate</p>\r\n<p><b>Email: </b>lilia.sacareanu@mail.ru</p>\r\n                        </div>\r\n                        <div class=\"col-md-12 col-sm-12 description-catedra\">\r\n                            <p>Disciplinele din cadrul catedrei:</p>\r\n                            <!--ul>\r\n                                <li>Proiectarea şi Crearea Paginilor WEB(HTML, CSS, PHP, JavaScript);</li>\r\n                                <li>Reţele de Calculatoare;</li>\r\n                                <li>Programarea Orientată spre Obiecte(JAVA);</li>\r\n                                <li> Sisteme de Gestiune a Bazelor de Date [...]</li>   \r\n                            </ul-->\r\n                            <p><a class=\"btn-u btn-u-sm\" href=\"\">Read More <i class=\"fa fa-angle-double-right margin-left-5\"></i></a></p>\r\n                        </div>\r\n                    </div>', '2017-11-03 11:19:08', '2017-11-03 10:19:08'),
(4, 'Catedra de Filologie', '<div class=\"col-md-6 catedra-content\">\r\n                        <div class=\"col-md-6 padding\">\r\n                            <img src=\"assets/img/team/user-d.png\" alt=\"\" class=\"img-responsive\">\r\n                        </div>\r\n                        <div class=\"col-md-6 padding\">\r\n                            <span>Bob Oxana</span>\r\n                            <small>- Șef catedră Filologie -</small>\r\n                            <p>Grad didactic unu, profesor de limba română</p>\r\n<p><b>Email: </b>oxanabob@mail.ru</p>\r\n                        </div>\r\n                        <div class=\"col-md-12 col-sm-12 description-catedra\">\r\n                            <p>Disciplinele din cadrul catedrei:</p>\r\n                            <!--ul>\r\n                                <li>Proiectarea şi Crearea Paginilor WEB(HTML, CSS, PHP, JavaScript);</li>\r\n                                <li>Reţele de Calculatoare;</li>\r\n                                <li>Programarea Orientată spre Obiecte(JAVA);</li>\r\n                                <li> Sisteme de Gestiune a Bazelor de Date [...]</li>   \r\n                            </ul-->\r\n                            <p><a class=\"btn-u btn-u-sm\" href=\"\">Read More <i class=\"fa fa-angle-double-right margin-left-5\"></i></a></p>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"col-md-6 catedra-title\">\r\n                        <div class=\"col-md-12 bg-blue\">\r\n                            \r\n                            <p>Catedra de </p>Filologie<br>\r\n                            <i class=\"fa fa-book\" style=\"font-size:90px\"></i>\r\n                        </div>\r\n                    </div>', '2017-11-03 11:26:59', '2017-11-03 10:26:59'),
(5, 'Catedra de Economie', '<div class=\"col-md-6 catedra-title\">\r\n                        <div class=\"col-md-12 bg-blue\">\r\n                            \r\n                            <p>Catedra de </p>Economie<br>\r\n                            <i class=\"fa fa-euro\" style=\"font-size:90px\"></i>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"col-md-6 catedra-content\">\r\n                        <div class=\"col-md-6 padding\">\r\n                            <img src=\"assets/img/team/DSC_8578.jpg\" alt=\"\" class=\"img-responsive\">\r\n                        </div>\r\n                        <div class=\"col-md-6 padding\">\r\n                            <span>JOLEA ECATERINA</span>\r\n                            <small>- Șef Catedră Economie -</small>\r\n                            <p>Grad didactic doi, profesor discipline de specialitate</p>\r\n<p><b>Email: </b>j.e.m@rabler.ru</p>\r\n                        </div>\r\n                        <div class=\"col-md-12 col-sm-12 description-catedra\">\r\n                            <p>Disciplinele din cadrul catedrei:</p>\r\n                            <!--ul>\r\n                                <li>Proiectarea şi Crearea Paginilor WEB(HTML, CSS, PHP, JavaScript);</li>\r\n                                <li>Reţele de Calculatoare;</li>\r\n                                <li>Programarea Orientată spre Obiecte(JAVA);</li>\r\n                                <li> Sisteme de Gestiune a Bazelor de Date [...]</li>   \r\n                            </ul-->\r\n                            <p><a class=\"btn-u btn-u-sm\" href=\"\">Read More <i class=\"fa fa-angle-double-right margin-left-5\"></i></a></p>\r\n                        </div>\r\n                    </div>', '2017-11-03 10:57:20', '2017-11-03 09:57:20'),
(10, 'Catedra de Asistenta Sociala', '<div class=\"col-md-6 catedra-content\">\r\n                        <div class=\"col-md-6 padding\">\r\n                            <img src=\"assets/img/team/DSC_8541.jpg\" alt=\"\" class=\"img-responsive\">\r\n                        </div>\r\n                        <div class=\"col-md-6 padding\">\r\n                            <span>Dănilă Larisa</span>\r\n                            <small>- Șef Catedră Asistenţă Socială -</small>\r\n                            <p>Grad didactic unu, profesor discipline de specialitate</p>\r\n                        </div>\r\n                        <div class=\"col-md-12 col-sm-12 description-catedra\">\r\n                            <p>Disciplinele din cadrul catedrei:</p>\r\n                            <!--ul>\r\n                                <li>Proiectarea şi Crearea Paginilor WEB(HTML, CSS, PHP, JavaScript);</li>\r\n                                <li>Reţele de Calculatoare;</li>\r\n                                <li>Programarea Orientată spre Obiecte(JAVA);</li>\r\n                                <li> Sisteme de Gestiune a Bazelor de Date [...]</li>   \r\n                            </ul-->\r\n                            <p><a class=\"btn-u btn-u-sm\" href=\"\">Read More <i class=\"fa fa-angle-double-right margin-left-5\"></i></a></p>\r\n                        </div>\r\n                    </div>\r\n                    <div class=\"col-md-6 catedra-title\">\r\n                        <div class=\"col-md-12 bg-blue\">\r\n                            \r\n                            <p>Catedra de </p>Asistenţă Socială<br>\r\n                <i class=\"fa fa-heart\" style=\"font-size:90px;\"></i>\r\n                        </div>\r\n                    </div>', '2017-11-03 11:15:41', '2017-11-03 10:15:41');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `intrebari_fregvente`
--

CREATE TABLE `intrebari_fregvente` (
  `id` int(11) NOT NULL,
  `intrebare` varchar(255) NOT NULL,
  `raspuns` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Salvarea datelor din tabel `intrebari_fregvente`
--

INSERT INTO `intrebari_fregvente` (`id`, `intrebare`, `raspuns`) VALUES
(1, '1.În ce perioadă se desfășoară concursul de admitere?', 'Concursul de admitere se desfășoară în perioada: 17 iulie-05 august'),
(2, '2.Când se vor anunța rezultatele?', 'Rezultatele admiterii se vor face public pînă la 08 august 2017, și vor putea fi afișate atât pe panoul informativ din fața instituție, cât și pe site.'),
(3, '3.La ce specialități putem beneficia de finanțare bugetară?', 'La toate specialitățile sunt locuri cu finanțare bugetară. Pentru mai multe detalii vezi planul de admitere.'),
(4, '4.Ce se întâmplă dacă nu trec concursul la buget?', 'Candidaţii care nu vor trece concursul la locurile bugetare sunt înmatriculaţi la studii în bază de contract.'),
(5, '5.Care este taxa anulă de studii pentru elevii înmatriculaţi la studii în bază de contract?', 'Taxa anuala de studii pentru elevii care vor fi înmatriculați la studii în bază de contract constituie 5950 lei.');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `main_sliders`
--

CREATE TABLE `main_sliders` (
  `id` int(11) NOT NULL,
  `image` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `main_sliders`
--

INSERT INTO `main_sliders` (`id`, `image`) VALUES
(1, 'assets/img/main_slider/bg1.jpg'),
(2, 'assets/img/main_slider/bg2.jpg'),
(3, 'assets/img/main_slider/bg3.jpg'),
(4, 'assets/img/main_slider/bg4.jpg'),
(5, 'assets/img/main_slider/bg5.jpg'),
(6, 'assets/img/main_slider/bg6.jpg'),
(7, 'assets/img/main_slider/bg7.jpg'),
(8, 'assets/img/main_slider/bg8.jpg'),
(9, 'assets/img/main_slider/bg9.jpg'),
(10, 'assets/img/main_slider/bg10.jpg');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `menulist` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Salvarea datelor din tabel `menus`
--

INSERT INTO `menus` (`id`, `menulist`) VALUES
(1, 'Acasă'),
(2, 'Specialități'),
(3, 'Admitere'),
(4, 'Orar'),
(5, 'Evenimente'),
(6, 'Despre'),
(7, 'Contacte');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `parteners`
--

CREATE TABLE `parteners` (
  `id` int(11) NOT NULL,
  `image` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Salvarea datelor din tabel `parteners`
--

INSERT INTO `parteners` (`id`, `image`) VALUES
(1, 'assets\\img\\Colaborators\\red_sky.png'),
(2, 'assets\\img\\Colaborators\\ATIC.jpg'),
(3, 'assets\\img\\Colaborators\\bina.png'),
(4, 'assets\\img\\Colaborators\\Cisco.jpg'),
(5, 'assets\\img\\Colaborators\\contact.jpg'),
(6, 'assets\\img\\Colaborators\\crc.png'),
(7, 'assets\\img\\Colaborators\\microsoft.png'),
(8, 'assets\\img\\Colaborators\\me.png'),
(10, 'assets\\img\\Colaborators\\prod.png');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `specialities`
--

CREATE TABLE `specialities` (
  `id` int(11) NOT NULL,
  `denumire` varchar(100) NOT NULL,
  `nr` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Salvarea datelor din tabel `specialities`
--

INSERT INTO `specialities` (`id`, `denumire`, `nr`, `content`, `created_at`, `updated_at`) VALUES
(1, 'Informatica', 300, '<div class=\"container content\">\r\n			<div class=\"title-box-v2\">\r\n				<h2>SPECIALITATEA INFORMATICA</h2>\r\n			</div>    \r\n			<!-- Left Inner -->\r\n			<div class=\"left-inner\">\r\n				<img class=\"\" src=\"../assets/img/Info_sp/info.jpg\" alt=\"\">\r\n				<p>Secţia Informatică funcţionează în cadrul Colegiului Industrial-Pedagogic din Cahul şi asigură pregătirea specialiştilor în domeniul tehnologiilor informaţionale la nivelul învăţămîntului vocational tehnic postsecundar.</p>\r\n\r\n				<hr>\r\n\r\n				<h2>ASPECTE</h2>\r\n				<p> Absolvenţii specialităţii “Informatică” obţin calificarea “Tehnician” şi pot activa în calitate de:</p>\r\n				<ul class=\"list-unstyled\">\r\n					<li><i class=\"color-green fa fa-check\"></i> administrator sistem documentar;</li>\r\n					<li><i class=\"color-green fa fa-check\"></i> operator calculator electronic şi reţele;</li>\r\n					<li><i class=\"color-green fa fa-check\"></i> operator suport tehnic pentru servicii de comunicaţii electronice;</li>\r\n                                        <li><i class=\"color-green fa fa-check\"></i> asistent comunicaţii (calculatoare);</li>\r\n<li><i class=\"color-green fa fa-check\"></i> asistent pentru baze de date;</li>\r\n<li><i class=\"color-green fa fa-check\"></i> asistent programator;</li>\r\n<li><i class=\"color-green fa fa-check\"></i> webmaster;</li>\r\n<li><i class=\"color-green fa fa-check\"></i> tehnician testarea produselor-program.</li>\r\n				</ul>\r\n\r\n				<hr>\r\n                                <p>Profesorii catedrei participă activ şi cu succes la nivel naţional în elaborarea planurilor de învăţămînt, a curriculum-ului la disciplinele de specialitate. Sînt experţi în elaborarea calficărilor pentru Domeniul de formare profesională Utilizarea calculatorului. </p>\r\n                                <p>În cadrul secţiei activează catedra \"Informatică”. Procesul de studii este asigurat de 12 cadre didactice: 2 cadre didactice - grad superior, 4 cadre didactice gradul didactic II, 6 tineri specialişti. </p>\r\n                                <p>Pentru a realiza cu succes această ofertă educaţională, este creat un mediu educaţional adecvat, calitativ şi productiv, centrat pe elev, care se bazează pe următoarele principii de organizare a formării:</p>\r\n				<div class=\"row\">\r\n					<div class=\"col-md-6\">\r\n						<ul>\r\n							<li>crearea unui mediu de învăţare autentic, apropiat de mediul afacerilor şi relevant intereselor elevului, pentru realizarea obiectivelor proiectate: însuşirea de cunoştinţe, formarea de deprinderi şi de competenţe personale şi profesionale;</li>\r\n							<li>îmbinarea aspectelor de natură teoretică şi cultivarea unor abilităţi legate de realităţile activităţilor din domeniul informaticii;</li>    \r\n						</ul>\r\n					</div>\r\n					<div class=\"col-md-6\">    \r\n						<ul>\r\n							<li>structura demersurilor educaţionale pe concepţia „învaţă acţionând” şi dezvoltarea unor dexterităţi de ordin practic;</li>\r\n                                                        <li>valorificarea unor tehnici modeme de instruire, inclusiv de dezvoltare a creativităţii.</li>\r\n						</ul>\r\n					</div>\r\n				</div>\r\n\r\n				<hr>\r\n				<p>Ca unitate independentă, Secţia Informatică, a fost fondată în anul 2009. Până atunci a fost Secţia integrată Contabilitate-Informatică. Colegiul a avut prima admitere în anul 2002, prin înmatricularea a 26 de elevi la specialitatea Informatică. Secţia Informatică şi-a asumat şi va continua să instaureze prin elevii şi profesorii ei o geometrie spirituală perfect adaptabilă regulilor impuse de contextul social, economic şi cultural. Rezultatele obţinute până acum justifică faptul că secţia se caracterizează printr-o constantă aspiraţie spre excelenţă, menită să asigure o evoluţie trainică a personalităţii.</p>\r\n<p>Elevi şi profesori, deopotrivă, acced spre modernitate prin dezvoltarea unui spirit de colaborare, prin asumarea libertăţii de gândire şi expresie, printr-un efort considerabil de cultivare a cunoaşterii. </p>\r\n<p>Secţia este pregătită să facă faţă oricărei provocări, concentrându-şi eforturile pentru formarea elevilor ca personalităţi ai societăţii globale de mâine, oferindu-le posibilitatea de a-şi îmbogăţi cunoştinţele, de a-şi dezvolta abilităţile, deschizându-le calea către mari universităţi din ţară şi străinătate. Realizează acest lucm printr-o îmbinare armonioasă a metodelor şi tehnicilor tradiţionale de învăţare cu cele modeme, impuse de transformările rapide pe care le parcurge societatea şi pe care secţia trebuie să le asimileze şi, eventual, să le anticipeze. </p>\r\n<p>Misiunea Secţiei, conturată în cadrul strategiei educaţionale de dezvoltare bazată competenţe, este de a optimiza continuu formele de educaţie pe care le dezvoltă.</p>\r\n<p>In anul 2005 a fost lansată prima promoţie constituită din 22 de absolvenţi, cărora după susţinerea examenelor de absolvire li s-a atribuit calificarea de technician-programator.</p>\r\n<p>Pe parcursul anilor 2008 - 2015 la Secţia Informatică şi-au făcut studiile 395 de elevi. O bună parte din absolvenţii acestei specialităţi activează în toate domeniile ce necesită metode contemporane de acumulare, procesare şi transmitere a informaţiei. Unii îşi continuă studiile la diferite universităţi din ţară, dar si din România, Rusia, Germania, la specialităţi înrudite cu cea obţinută în colegiu. Deoarece viaţa cotidiană este neconcepută fără TIC, agenţii economici din teritoriu, tot mai frecvent, solicită angajarea absolvenţiilor de la specialitatea Informatică. Crearea paginilor WEB pentru licee, primării, centre comerciale, diferite colective şi a unor programe de gestionare a bunurilor, elaborarea diverselor aplicaţii personale şi a unor baze de date - sunt ofertele principale din teritoriu pentru angajarea în câmpul muncii a tinerilor specialişti în domeniu.</p> \r\n\r\n				\r\n				</div>\r\n			<!-- End Left Inner -->\r\n		</div>   ', '2017-10-20 17:50:30', '0000-00-00 00:00:00'),
(2, 'Asistenta Sociala', 200, '<div class=\"container content slideanim\">\r\n			<div class=\"title-box-v2\">\r\n				<h2>SPECIALITATEA ASISTENȚĂ SOCIALĂ</h2>\r\n			</div>    \r\n			<!-- Left Inner -->\r\n			<div class=\"left-inner\">\r\n				<img src=\"../assets/img/Info_sp/social.png\" alt=\"\">\r\n				<p>Secția Pedagogie și Asistență socială asigură pregătirea cadrelor la specialitățile:</p>\r\n				<ul class=\"list-unstyled\">\r\n					<li><i class=\"color-green fa fa-check\"></i> 1203 Pedagogia Învățământului Primar, calificarea: Învățător;</li>\r\n					<li><i class=\"color-green fa fa-check\"></i> 1202 Pedagogie Preșcolară, calificarea: Educator în instituțiile preșcolare;</li>\r\n					<li><i class=\"color-green fa fa-check\"></i> 1271 Asistența Socială, calificarea: Asistent social.</li>\r\n             			</ul>\r\n                                <hr>\r\n                                <p>Instruirea elevilor la specialitățile respective este asigurată de activitatea didactică a cadrelor: Pedagogie, Psihologie și Asistență SOcială, Științe Reale, Filologie și Istorie, Arte.</p>\r\n				<hr>\r\n				<p>Catedra Pedagogie, Psihologie și Asistență Socială și-a început activitatea, trecând prin etape diferite, cu susținerea și impedimente, alimentată fiind ascensiunea de oameni cu o enormă capacitate de muncă, dragoste de profesie și de cei pentru care s-au simțit responsabili: discipoli și generații ce s-au perindat ani și ani și care au completat marea oaste  de specialiști calificați, care s-au dedicat totalmente procesului de formare și reformare a societății.</p>\r\n                                <hr>\r\n                                <p>Cadrele didactice ce activează în cadrul catedrei depun efort pentru ca organizarea procesului de învățămînt să se axeze pe crearea unui sistem educațional modern, adecvat unei lumi dinamice, care să opteze pentru performanțe și calitate.   Activitatea didactică a catedrei este asigurată   de  14 cadre didactice:</p>\r\n                                <div class=\"row\">\r\n					<div class=\"col-md-6\">\r\n						<ul>\r\n							<li>4 cadre didactice – grad superior;</li>\r\n							<li>4 cadre didactice grad didactic I;</li>\r\n						</ul>\r\n					</div>\r\n					<div class=\"col-md-6\">    \r\n						<ul>\r\n							<li>3 cadre didactice grad didactic II;;</li>\r\n							<li>3- tineri specialiști.</li>\r\n						</ul>\r\n					</div>\r\n				</div>\r\n			</div>\r\n			<!-- End Left Inner -->\r\n		</div>   ', '2017-10-20 17:50:40', '0000-00-00 00:00:00'),
(3, 'Contabilitate', 250, '<div class=\"container content slideanim\">\r\n			<div class=\"title-box-v2\">\r\n				<h2>SPECIALITATEA CONTABILITATE</h2>\r\n			</div>    \r\n			<!-- Left Inner -->\r\n			<div class=\"left-inner\">\r\n				<img src=\"../assets/img/Info_sp/cont.png\" alt=\"\">\r\n				<p>Misiunea Secției Contabilitate și a Catedrei de Economie constitituie: pregătirea specialiştilor în domeniul economic,  specialitatea Contabilitate, ce  prezintă interes pe piaţa muncii.</p>\r\n\r\n				<hr>\r\n\r\n				<h2>ASPECTE</h2>\r\n				<p> „Contabilitatea” are scop de a pregăti specialişti competenţi ce se referă la una din următoarele activităţi :</p>\r\n				<ul class=\"list-unstyled\">\r\n					<li><i class=\"color-green fa fa-check\"></i> Organizarea şi desfăşurarea relaţiilor financiare;</li>\r\n					<li><i class=\"color-green fa fa-check\"></i> Gestionarea contabilităţii la diferite sectoare de evidenţă;</li>\r\n					<li><i class=\"color-green fa fa-check\"></i> Elaborarea sistemului de control intern;</li>\r\n                                        <li><i class=\"color-green fa fa-check\"></i> Efectuarea analizei activităţii economico -financiare ale entităţii economice.</li>\r\n				</ul>\r\n\r\n				<hr>\r\n                                <p>Calificarea  contabil cuprinde totalitatea activităţilor cu caracter economic care presupun cunoştinţe in domeniul contabilităţii, comunitatea specialiştilor care efectuează activităţile în cauză (contabilii şi auditorii) precum şi organismele lor profesionale. Prin urmare ca obiective ale calificării contabile putem cataloga desfăşurarea activităţii în corespundere cu standardele profesionale, atingerea unui nivel înalt de performanţă a serviciilor prestate</p>\r\n                                <p>În orice calificare şi cu atât mai mult în domeniul economic, prin natura problematicilor ei, în contextul globalizării economiei mondiale, este necesară aşezarea acesteia pe principii fundamentale, menite sa asigure standarde înalte de profesionalism şi calitate. În exercitarea calificării sale contabilul trebuie să-şi conducă activitatea apelând şi respectând cele trei comandamente ale calificării contabile, pe care le-am defini ca valori ale calificării: educaţia, etica şi calitatea serviciilor prestate.</p>\r\n                                <p>Din punctul de vedere provocările actuale ale calificării contabile sunt determinate de următorii factori:</p>\r\n				<div class=\"row\">\r\n					<div class=\"col-md-6\">\r\n						<ul>\r\n							<li>Factorul uman;</li>\r\n							<li>Relaţia dintre contabilitate şi fiscalitate;;</li>    \r\n						</ul>\r\n					</div>\r\n					<div class=\"col-md-6\">    \r\n						<ul>\r\n							<li>Precondiţii în implementarea şi aplicarea IFRS şi SNC;</li>\r\n                                                        <li>Calitatea serviciilor prestate.</li>\r\n						</ul>\r\n					</div>\r\n				</div>\r\n\r\n				<hr>\r\n				<p>Prim şi cel mai important aspect prin care se caracterizează şi se manifestă calificarea  contabilă este factorul uman caracterizat prin educaţie, etică şi raţionament profesional.</p>\r\n				\r\n				</div>\r\n			<!-- End Left Inner -->\r\n		</div>   ', '2017-10-20 17:50:48', '0000-00-00 00:00:00'),
(4, 'Arte', 150, '<div class=\"container content slideanim\">\r\n			<div class=\"title-box-v2\">\r\n				<h2>SPECIALITATEA ARTE</h2>\r\n			</div>    \r\n			<!-- Left Inner -->\r\n			<div class=\"left-inner\">	\r\n				<p>Secţia Arte a fost iniţiată în august 1994 cu două specialităţi: Interpretare instrumentală şi Dirijare corală. În august 1995a fost deschisă specialitatea 1604 Instruire în arte plastice cu scopul de a pregăti profesori de artă plastică pentru şcolile de arte şi gimnaziile din republică. În anul de învăţămînt 2004 - 2005 a fost deschisă specialitatea 1404 Instruire muzicală cu calificarea Învăţător de muzică în clasele primare, profesor de muzică. În  2014  au fost înmatriculați elevi la specialitatea 1503  Coregrafie, iar  în  2015  la  specialitatea  1601 Pictură.</p>\r\n	\r\n				<p>În  cadrul  Colegiului  Industrial-Pedagogic din Cahul activează de 21 ani secţia Arte, obiectivul general al căreia este pregătirea şi  promovarea tinerilor specialişti  în  domeniul Artei. În cadrul catedrei activează 23 profesori, din ei 2 au grad didactic superior, 4 grad didactic unu, 13 grad didactic doi, 4 confirmați în funcție.</p>\r\n				<hr>\r\n                                <br>\r\n                                <div class=\"title-box-v2\">\r\n				<h2>SPECIALITATI</h2>\r\n                                </div>\r\n                                <div class=\"title-box-v2\">\r\n				<h2>INTERPRETARE INSTRUMENTALĂ</h2>\r\n                                </div>\r\n                                \r\n                                <img src=\"../assets/img/Info_sp/arte2.png\" alt=\"\">\r\n                                <p>Obiectivul general al specialităţii Interpretare instrumentală este pregătirea artiştilor-instrumentişti, profesorilor pentru şcolile de muzică. Elevii studiază aprofundat următoarele instrumente: pian, vioară,  contrabas, acordeon, ţambal, trompetă, clarinet. Deasemenea şi un şir de discipline de specialitate, menite să dezvolte abilităţile profesionale: solfegiu, teoria muzicii, literatura muzicală, orchestra, orchestraţia, lectura partiturilor, ansamblul cameral etc.</p>\r\n                                <p>Absolvenții specialității Interpretare Instrumentală s-au încadrat în câmpul muncii în școlile de arte, asamblul de acordeoniști Concertino (Podceaha Olga), orchestra prezidențială (Chiciuc Igor), orchestra simfonică a Filarmonicii de Stat (Gaju Gheorghe) etc.</p>\r\n				<p>Elevii secţiei sunt încadraţi în cor, orchestra de muzică populară, ansamblul vocal, participă la diverse activităţi extradidactice – serate tematice, concerte de clasă, spectacole muzicale, expoziţii. Evoluînd la Festivalul Republican al creaţiei artistice a tineretului studios din instituţiile de învăţămînt superior din Republica Moldova în anul 2003, ne-am plasat pe locul III. Rezultate îmbucurătoare am obţinut şi la Concursul profesional al instituţiilor medii de specialitate cu profil muzical -pedagogic, care a avut loc la 7 aprilie 2006 în Călăraşi (2 locuri I, 2 locuri II, 2 locuri III). Participăm permanent la Concursul Republican de muzică instrumentală şi vocală ”Ştefan Neaga”, la ediţia din anul 2009 am luat 3 locuri III: elevii clasei prof. Ababei Alexei - Şeremet C. (trompetă), Ababei V. (ţambal), precum şi Bîrcă D. (acordeon), clasa prof. Gorceacov Vasile. La ediția XIX din 24-26.04.2013 elevei  Chiriac E. (pian), clasa prof. Latu N. i  s-a  acordat  locul III.</p>\r\n<hr><br>				\r\n\r\n<div class=\"title-box-v2\">\r\n				<h2>INSTRUIRE ÎN ARTE PLASTICE</h2>\r\n                                </div>\r\n\r\n                                <p> <img src=\"../assets/img/Info_sp/arte3.jpg\" alt=\"\">Specialitatea Instruire în arte plastice are drept obiectiv pregătirea profesorilor de artă plastică. Pentru a deveni un specialist de o înaltă calificare elevii studiază diverse discipline de profil aşa ca:desenul,pictura,compoziţia,istoria artelor,anatomia plastică etc.Elevii însuşesc diferite genuri de artă plastică,utilizează diverse tehnici de executare şi aplicare, lucrează în creion,cărbune,ulei, acuarelă,pastel.</p>\r\n<p>Se utilizeaza suporturi diverse pe care se aplica culoarea precum: hartia, cartonul, sticla, panza, etc.Culorile care se aplica pe suport sunt de asemenea de mai multe feluri, respectiv: culorile de apa(cerneluri, tusuri, acuarele, guase, tempere, acrilice), culori de ulei(care se dizolva in diluanti specifici), culori de ceara, pasteluri, etc. Sunt utilizate si tehnici mixte cu conditia compatibilitatii materialelor utilizate.</p>\r\n<p>Viziunea noastră, o lume mai bună prin artă, rezumă succint credința că arta este cea mai înaltă manifestare a spiritului uman, o forță pentru bine, care poate să aducă armonie, toleranță și înțelegere între oameni, indiferent de rasă, etnie, naționalitate, religie sau statut socio-economic.</p>\r\n			<p> Misiunea Colegiului \"Iulia Hasdeu\" este:</p>\r\n				<ul class=\"list-unstyled\">\r\n					<li><i class=\"color-green fa fa-check\"></i> de a șlefui talentul elevilor noștri și de a educa gustului artistic și estetic al acestora</li>\r\n<li><i class=\"color-green fa fa-check\"></i> de a pune în valoare atât nivelul lor intelectual cât și măiestria lor artistică</li>\r\n<li><i class=\"color-green fa fa-check\"></i> de a dezvolta particularitățile lor individuale pentru a-i determina să obțină o autodisciplină comportamentală și o mai mare implicare atât în sfera activităților artistice și culturale cât și în sfera socială și comunitară</li>\r\n\r\n				</ul>\r\n<p>Astfel, absolvenții liceului nostru au oportunitatea să devină agenți ai schimbării, care prin puterea artei să facă lumea un loc mai bun pentru toți.</p>\r\n<hr>\r\n                                <br>\r\n<div class=\"title-box-v2\">\r\n				<h2>COREGRAFIE</h2>\r\n                                </div>\r\n                                \r\n                                <img src=\"../assets/img/Info_sp/arte4.jpg\" alt=\"\">\r\n                                <p>Specialitatea Coregrafie are drept  scop educarea și formarea tinerilor specialiști în domeniul artei coregrafice.Pentru a deveni specialiști competitivi pe piața muncii elevii studiază un șir de discipline menite să contribuie la formarea competențelor profesionale:dans clasic,dans popular scenic,compoziția și montarea dansului,descrierea și schematizarea dansului,dans de epocă etc. \r\nElevii secţiei sunt încadraţi în cor,orchestra de muzică populară,ansamblul vocal,participă la diverse activităţi extradidactice – serate tematice,concerte de clasă,spectacole muzi- cale,expoziţii.Evoluînd la Festivalul Republican al creaţiei artistice a tineretului studios din insti-tuţiile de învăţămînt superior din Republica Moldova în anul 2003,ne-am plasat pe locul III.Re- zultate îmbucurătoare am obţinut şi la Concursul profesional al instituţiilor medii de specialitate cu profil muzical-pedagogic,care a avut loc la 7 aprilie 2006 în Călăraşi(2 locuri I,2 locuri II, 2 locuri III).Participăm permanent la Concursul Republican de muzică instrumentală şi vocală,,Şte fan Neaga”,la ediţia din anul 2009 am luat 3 locuri III – elevii clasei prof.Ababei Alexei-Şeremet C.(trompetă),Ababei V.(ţambal), precum şi Bîrcă D.(acordeon),clasa prof. Gorceacov Vasile.La ediția XIX din 24-26.04.2013 elevei  Chiriac E.(pian),clasa prof.Latu N. i  s-a  acordat  locul III.\r\n</p>			\r\n<p>În anul 2005 din îndemnul secţiei Arte a fost inaugurat festivalul vocal – coral ,,Nicolae Ştiuca”.\r\nIniţiat la un an de la trecerea în eternitate a talentatului dirijor şi profesor Nicolae Ştiuca festiva-lul are ca obiective propagarea muzicii corale naţionale şi universale,lansarea şi promovarea tinerelor talente. La 8 mai 2011 s-a desfăşurat  ediţia a IV a acestui festival.\r\n</p>\r\n<hr>\r\n<p>Majoritatea absolvenţilor secţiei Arte şi-au continuat studiile atît în instituţiile de învăţămînt superior din Moldova,cît şi din România,Bulgaria,Rusia.Absolvenţii specialităţii Interpretare instrumentală s-au încadrat în cîmpul muncii în şcolile de arte, ansamblul de acordeonişti Concertino(Podceaha Olga),orchestra prezidenţială (Chiciuc Igor),orchestra simfonică a Filarmonicii de Stat(Gaju Gheorghe),orchestra de muzică populară,,Mărțișor,,(Chiper V.,Ababei V.),orchestra de muzică populară Mugurel(Volog Vitalie),orchestra brigăzii militare Dacia(Gîscă Valeriu,Popov Viorel,Mihnea Andrei,MovileanuVitalie).Absolvenţii specialităţilor Dirijare corală,Instruire muzicală s-au angajat în calitate de profesori de educaţie muzicală şi conducători de cor în instituţiile de învăţămînt preuniversitar din republică.Absolvenţii specialităţii Instruire în arte plastice se manifestă ca profesori de artă plastică în şcolile de arte plastice şi gimnazii.Succese deosebite are absolventa specialităţii Dirijare corală Olga Ţîra,absolventă a Academiei de Muzică,Teatru şi Arte plastice din Chişinău,laureată a mai multor concursuri naţionale şi internaţionale,participantă a concursului Eurovizion 2010.Ne bucură mult şi realizările absolventei specialităţii Instruire muzicală Stela Botez,actualmente  absolventa Aca-demia de Muzică,Teatru şi Arte plastice din Chişinău,deţinătoarea Premiului Mare a concursului de muzică uşoară din Bulgaria(2006),deţinătoarea Premiului Mare a Festivalului Folcloric,,Nico- lae Sulac” ed.I(10.04.07),laureată a Jocurilor Delfice organizate în Chişinău în luna mai 2010 (loc.II).Absolventa specialității Instruire muzicală Chiciuc Natalia, actualmente este lector-doctorand la catedra Compoziție și Muzicologie,a Academiei de Muzică, Teatru și Arte plastice din Chișinău.\r\nBineînţeles că toate aceste realizări nu ar fi fost posibile fără aportul cadrelor didactice ce activează în cadrul secţiei.Dispunem de pedagogi creativi,cu un vast orizont de cunoştinţe în domeniul culturii umane.\r\n</p>\r\n</div>\r\n\r\n			<!-- End Left Inner -->\r\n		</div>   ', '2017-10-20 17:50:56', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Salvarea datelor din tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'Padure Gheorghe', 'paduregheorghe7@gmail.com', '$2y$10$5opBSVSjDFRUF4aJGA.LhOGYacoE.LHOOCvWjzWICfHMsCr8ULEz6', '1eGW6QKiYJQ1kb0lZh9tcxz5YlH3EVZMK4ZGyZ6UJfK0LL57XN2mkmOu0vhw', '2017-09-05 10:24:18', '2017-09-30 17:32:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acte`
--
ALTER TABLE `acte`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `administratias`
--
ALTER TABLE `administratias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carousels`
--
ALTER TABLE `carousels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `catedres`
--
ALTER TABLE `catedres`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `intrebari_fregvente`
--
ALTER TABLE `intrebari_fregvente`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `main_sliders`
--
ALTER TABLE `main_sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parteners`
--
ALTER TABLE `parteners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `specialities`
--
ALTER TABLE `specialities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acte`
--
ALTER TABLE `acte`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `administratias`
--
ALTER TABLE `administratias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `carousels`
--
ALTER TABLE `carousels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `catedres`
--
ALTER TABLE `catedres`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `intrebari_fregvente`
--
ALTER TABLE `intrebari_fregvente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `parteners`
--
ALTER TABLE `parteners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `specialities`
--
ALTER TABLE `specialities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
